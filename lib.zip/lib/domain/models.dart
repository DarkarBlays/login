class Usuario{
  var nombre,clave;

  Usuario({this.nombre,this.clave});

}

List<Usuario> listaUsuarios = [
  Usuario(nombre: 'Alex',clave: '123'),
  Usuario(nombre: 'Pedro',clave: '456'),
  Usuario(nombre: 'Maria',clave: '789'),
];