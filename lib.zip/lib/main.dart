import 'package:flutter/material.dart';
import 'package:login/ui/app.dart';

void main() {
  runApp(const App());
}
